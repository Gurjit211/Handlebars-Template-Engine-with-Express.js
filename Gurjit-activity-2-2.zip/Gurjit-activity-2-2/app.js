const express = require("express");
const exphbs = require("express-handlebars");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Set Handlebars as the view engine
app.engine("hbs", exphbs.engine({ extname: ".hbs" }));
app.set("view engine", "hbs");
app.set("views", "./views"); // ✅ Ensure this is correct

// Serve static files (CSS, JS, images)
app.use(express.static("public"));

// Load data from data.json
const rawData = fs.readFileSync("data.json");
const songs = JSON.parse(rawData);

// Routes
app.get("/", (req, res) => {
    res.render("pages/home", { songs: songs }); // ✅ Corrected path
});

app.get("/about-us", (req, res) => {
    res.render("pages/about-us");
});

app.get("/contact-us", (req, res) => {
    res.render("pages/contact-us");
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
